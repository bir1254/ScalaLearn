package playgroung

object playground {
  def main(args: Array[String]): Unit = {
    println("Smile is the best medicine in the whole world so Smile Please...")
  }
}
