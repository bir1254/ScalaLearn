package exercises

class MyClass {
 def myFun():Unit=println("Hello Function")
 def addFun(x:Int=10 , y:Int=11):Int={
   x+y
 }
}
class Math extends MyClass{
  def subFun(x:Int, y:Int):Int=x-y;
  def mulFun(x:Int, y:Int):Int=x*y;
}
object myObject{
 def main(args: Array[String]):Unit={
   var p=new Math()
   p.myFun()
   println(p.addFun(25,15))
   println(p.subFun(25,15))
   println(p.mulFun(5,5))
 }
}
