package exercises

object mytestObject{
  def fun(): Unit ={
    println("Hello Scala")
  }
}
object TestScalaPower {
  def main(args:Array[String]):Unit={
    println("Hello")
    mytestObject.fun()
  }
}

