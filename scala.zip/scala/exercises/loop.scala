package exercises

object loop extends App {
  for (n: Int <- 0 to 5 by 5) {
    println("Birbal Bhai");

  }
}