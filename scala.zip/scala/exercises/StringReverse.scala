package exercises

object StringReverse {
  def main(args:Array[String]):Unit={
    var str="Hello Birbal Kumar";
    var word=str.split(" ");
    var reverseWord="";
    for(i <-word.length-1 to 0 by -1){
      reverseWord=reverseWord+" "+word(i);
    }
   print(reverseWord)
  }

}
