package exercises

object Factorial extends App{
  def evenOdd(n:Int): Unit={
    if(n%2==0){
      println(n+" is even number");
    }
    else{ 
      println(n+" is odd number");
    }
  }
  evenOdd(21);
}
