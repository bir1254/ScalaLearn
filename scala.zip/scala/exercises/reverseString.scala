package exercises

object reverseString {
  def main(args:Array[String]):Unit={
    var name="Birbal";
    var arr=name.toCharArray();
    var rev="";
    for(i<-arr.length-1 to 0 by -1){
      rev=rev+arr(i);
    }
    print(rev);
  }

}
