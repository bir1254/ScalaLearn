package exercises

object Fibo {
  def main(args: Array[String]):Unit={
    var a=0
    var b=1

    print(a+" "+b+" ");
    for(i:Int <- 2 to 10){

       var temp=a+b;
      print(temp+" ")
      a=b;
      b=temp;
    }
  }

}
