package lectures

object InterviewTest {
  def main(args:Array[String]):Unit={
 var a=0
    var b=1
    print(a+" "+b+" ")
    def febo(n:Int):Unit={
      if(n==0) return 1;
      var temp=a+b
      a=b;
      b=temp;
      print(temp+" ")

      febo(n-1)
    }
    febo(8);
  }

}
