package lectures

object testscala {
  def myFun(n:Int)=
    if (n % 2 == 0)
      println("Even");
    else
      println("Oddd");
  myFun(5)

  def main(args: Array[String]): Unit = {

  }
}
